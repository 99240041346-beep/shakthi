# CAMPUS SHAKTHI

English-only anonymous student safety & behaviour reporting platform.

## Included
- Anonymous reporting + private tracking token
- Two-way anonymous student/officer messaging
- AI-assisted triage (keyword-based MVP, human review required)
- Student safety dashboard
- Safety alerts
- Emergency SOS
- Campus safety points/map
- Safety resources
- Privacy center
- Admin command center
- Case status workflow
- Analytics and audit logs

## Local
```bash
python -m venv .venv
# Windows
.venv\\Scripts\\activate
# macOS/Linux
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000

Admin: `/admin/login` — default `admin` / `admin123` (change before deployment).

## Production hardening before real student use
- PostgreSQL instead of SQLite for hosted production
- Encrypted object storage for evidence + malware scanning
- SSO/MFA and role-based staff permissions
- CSRF protection, rate limiting, secure headers
- Data retention/deletion policy and access reviews
- Strong random secrets and rotated credentials
- Independent security/privacy review
- Clear institutional emergency escalation policy

The AI triage is advisory only and must not be used as proof of misconduct or as the sole basis for disciplinary decisions.


## Role-based portal login

- Student: `/student/login` — `student` / `student123`
- Security: `/security/login` — `security` / `security123`
- Admin: `/admin/login` — `admin` / `admin123`

Student reporting remains anonymous to reviewers; the login only protects access to the student portal and its live location/SOS controls. Change all demo credentials before production use.
